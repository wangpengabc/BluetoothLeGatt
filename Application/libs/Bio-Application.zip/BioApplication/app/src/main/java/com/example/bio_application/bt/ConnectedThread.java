package com.example.bio_application.bt;

import android.bluetooth.BluetoothSocket;
import android.renderscript.ScriptIntrinsicYuvToRGB;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;


/**
 * 通信相关 - 客户端与服务器建立连接成功后，用ConnectedThread收发数据
 * 1、发送数据
 * 2、接收数据
 */
public class ConnectedThread extends Thread{
    private static final String TAG = "ConnectedThread";
    private BluetoothSocket mmSocket;
    private InputStream mmInStream;
    private OutputStream mmOutStream;


    public ConnectedThread(BluetoothSocket socket){
        mmSocket = socket;
        InputStream tmpIn = null;
        OutputStream tmpOut = null;

        //使用临时对象获取输入和输出流，因为成员流是静态类型

        //1、获取 InputStream 和 OutputStream
        try {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) {
            Log.e(TAG,"CommunicateThread-->获取InputStream 和 OutputStream异常!");
        }

        mmInStream = tmpIn;
        mmOutStream = tmpOut;

        if(mmInStream != null){
            Log.d(TAG,"CommunicateThread-->已获取InputStream");
        }

        if(mmOutStream != null){
            Log.d(TAG,"CommunicateThread-->已获取OutputStream");
        }

    }

    //此方法由系统自动调用，必须由用户来重写
    public void run(){
        //最大缓存区 存放流
        byte[] buffer = new byte[1024];  //buffer store for the stream
        //从流的read()方法中读取的字节数
        int rcv_cnt = 0;  //bytes returned from read()
        //持续监听输入流直到发生异常
        boolean head1=false;
        boolean head2=false;
        boolean end=false;
        int data_cnt = 0;
        while(true){
            try {
                if(mmInStream == null){
                    Log.e(TAG,"CommunicateThread:run-->输入流mmInStream == null");
                    break;
                }
                //先判断是否有数据，有数据再读取
                if(mmInStream.available() != 0){
                    //2、接收数据
                    rcv_cnt = mmInStream.read(buffer);  //从(mmInStream)输入流中(读取内容)读取的一定数量字节数,并将它们存储到缓冲区buffer数组中，bytes为实际读取的字节数
                    byte[] bytes = Arrays.copyOf(buffer, rcv_cnt);  //存放实际读取的数据内容
                    byte[] data = new byte[4];
                    for(byte b : bytes){
                        int tmp = b&0xFF;
                        if(end && tmp==0x03){
                            if(onSendReceiveDataListener != null){
                                // data：BCG,ECG
                                onSendReceiveDataListener.onReceiveDataSuccess(data);  //成功收到消息
                            }
                            head1 = false;
                            head2 = false;
                            end = false;
                            data_cnt = 0;
                        }else if(data_cnt==4 && tmp==0x0F){
                            end = true;
                        }else if(head2){
                            data[data_cnt] = b;
                            data_cnt += 1;
                        }else if(head1 && tmp==0x00){
                            head2 = true;
                        }else if(tmp==0xAA) {
                            head1 = true;
                        }
                    }
                }
            } catch (IOException e) {
                Log.e(TAG,"CommunicateThread:run-->接收消息异常！" + e.getMessage());
                if(onSendReceiveDataListener != null){
                    onSendReceiveDataListener.onReceiveDataError("接收消息异常:" + e.getMessage());  //接收消息异常
                }
                //关闭流和socket
                boolean isClose = cancel();
                if(isClose){
                    Log.e(TAG,"CommunicateThread:run-->接收消息异常,成功断开连接！");
                }
                break;
            }
        }
    }

    //发送数据
    public boolean write(byte[] bytes){
        try {
            if(mmOutStream == null){
                Log.e(TAG, "mmOutStream == null");
                return false;
            }
            //发送数据
            mmOutStream.write(bytes);
            Log.d(TAG, "写入成功："+ bytes2String(bytes));
            return true;

        } catch (IOException e) {
            Log.e(TAG, "写入失败："+ bytes2String(bytes));
            return false;
        }
    }

    /**
     * 释放
     * @return   true 断开成功  false 断开失败
     */
    public boolean cancel(){
        try {
            if(mmInStream != null){
                mmInStream.close();  //关闭输入流
            }
            if(mmOutStream != null){
                mmOutStream.close();  //关闭输出流
            }
            if(mmSocket != null){
                mmSocket.close();   //关闭socket
            }
            mmInStream = null;
            mmOutStream = null;
            mmSocket = null;

            Log.w(TAG,"CommunicateThread:cancel-->成功断开连接");
            return true;

        } catch (IOException e) {
            // 任何一部分报错，都将强制关闭socket连接
            mmInStream = null;
            mmOutStream = null;
            mmSocket = null;
            Log.e(TAG, "CommunicateThread:cancel-->断开连接异常！" + e.getMessage());
            return false;
        }
    }

    /**
     * 字节数组-->字符串
     * @param b   字节数组
     * @return 字符串
     */
    public static String bytes2String(byte[] b) {
        if (null == b || b.length == 0) {
            return "";
        }
        String strContent = "";
        try {
            strContent = new String(b, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return strContent;
    }

    private OnSendReceiveDataListener onSendReceiveDataListener;

    public void setOnSendReceiveDataListener(OnSendReceiveDataListener onSendReceiveDataListener) {
        this.onSendReceiveDataListener = onSendReceiveDataListener;
    }

    //收发数据监听者
    public interface OnSendReceiveDataListener{
        void onReceiveDataSuccess(byte[] buffer);  //接收到数据
        void onReceiveDataError(String errorMsg);   //接收数据出错
    }
}
