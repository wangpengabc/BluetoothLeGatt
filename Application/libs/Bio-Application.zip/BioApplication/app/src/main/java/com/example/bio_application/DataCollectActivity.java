package com.example.bio_application;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bio_application.bt.ConnectThread;
import com.example.bio_application.bt.ConnectedThread;
import com.example.bio_application.db.DataBaseHelper;
import com.example.bio_application.predict.Classifier;
import com.example.bio_application.predict.QRSDetectorOffline;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Set;

import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.view.LineChartView;


// 需要修改的地方
// init中删除数据库操作
// 采集数据的button 初始状态 enable 为 false
// 信号绘制的size要改  清空图片怎么做
// 给蓝牙发送控制信号要改发送的内容
public class DataCollectActivity extends AppCompatActivity implements View.OnClickListener{
    private static final String TAG = "DataCollectActivity";
    // 接受状态信息标志
    private static final int DATA_MSG = 0x01;
    private static final int STATE_MSG = 0x02;

    // 信息填写部分控件
    private LinearLayout llInfoView;
    private EditText edtUserName;
    private RadioGroup rgUserGender;
    private EditText edtUserAge;
    private EditText edtUserHeight;
    private EditText edtUserWeight;
    private Button btnSaveInfo;
    // 信息填写部分变量
    private String checkedGender;
    private List<String> userInfo = null;
    // 下部控制按钮
    private Button btnConnect;
    private Button btnInfo;
    private Button btnCollect;
    private Button btnRecord;

    // 信号绘制部分控件
    private LinearLayout llChartView;
    private TextView tvBCG;
    private TextView tvECG;
    private TextView tvCNT;
    private LineChartView bcgChart = null;
    private LineChartView ecgChart = null;
    // 信号绘制部分变量
    private Line bcgLine = null;
    private Line ecgLine = null;
    private int refreshSize = 200;
    private Queue<String> drawDataQueue = null;
    // 模型推理部分
    private Button btnInference;
    private LinearLayout llInference;
    private TextView tvInference;
    private String dataSaveName;

    // 蓝牙相关控件
    private LinearLayout llBtInfo;
    private TextView deviceState = null;
    private TextView pairedDevice = null;
    // 蓝牙相关变量
    public BluetoothAdapter bluetoothAdapter = null;
    private final String targetBtDevice = "LQ_BTM1V2";       // 下位机蓝牙名称
    public boolean curConnState = false;   //当前设备连接状态
    private ConnectThread mmConnectThread = null;
    private ConnectedThread mmConnectedThread = null;
    // 记录收到的信号数据
    private List<String> recordData = null;
    private boolean isRecord = false;
    private int rcvCount = 0;
    private String externalFilesDirPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_collect);
        findViews();
        if (!bluetoothInit()) finish();
        initView();
    }

    protected void findViews() {
        // 用户信息登记相关控件
        llInfoView = findViewById(R.id.info_view);
        edtUserName = findViewById(R.id.edt_user_name);
        edtUserAge = findViewById(R.id.edt_user_age);
        edtUserHeight = findViewById(R.id.edt_user_height);
        edtUserWeight = findViewById(R.id.edt_user_weight);
        rgUserGender = findViewById(R.id.rg_user_gender);
        btnSaveInfo = findViewById(R.id.btn_save_info);
        // 下部按钮
        btnConnect = findViewById(R.id.btn_connect);
        btnInfo = findViewById(R.id.btn_info);
        btnCollect = findViewById(R.id.btn_collect);
        btnRecord = findViewById(R.id.btn_record);
        // 信号绘制部分
        llChartView = findViewById(R.id.charts_view);
        tvBCG = findViewById(R.id.data_bcg);
        tvECG = findViewById(R.id.data_ecg);
        tvCNT = findViewById(R.id.data_cnt);
        bcgChart = findViewById(R.id.chart_bcg);
        ecgChart = findViewById(R.id.chart_ecg);
        // 诊断相关
        btnInference = findViewById(R.id.btn_inference);
        llInference = findViewById(R.id.ll_inference);
        tvInference = findViewById(R.id.tv_inference);
        // 蓝牙相关
        llBtInfo = findViewById(R.id.bluetooth_info);
        pairedDevice = findViewById(R.id.paired_device);  // 显示当前配对的蓝牙
        deviceState = findViewById(R.id.device_state);   // 显示当前设备连接状态
    }

    protected void initView(){
        getPermission();
        externalFilesDirPath = this.getExternalFilesDir(null).getAbsolutePath();
        Log.d(TAG, "externalFilesDirPath->" + externalFilesDirPath);
        // externalFilesDirPath->/storage/emulated/0/Android/data/com.example.bio_application/files
        checkedGender = "男";
        rgUserGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.gender_male) checkedGender = "男";
                else checkedGender = "女";
            }
        });
        btnSaveInfo.setOnClickListener(this);
        btnConnect.setOnClickListener(this);
        btnInfo.setOnClickListener(this);
        btnCollect.setOnClickListener(this);
        btnRecord.setOnClickListener(this);
        btnInference.setOnClickListener(this);
        recordData = new ArrayList<>();
        drawDataQueue = new LinkedList<>();
        for(int i=0; i<refreshSize; i++) drawDataQueue.add("0,0");
        userInfo = new ArrayList<>();
//        DataBaseHelper dbHelper = new DataBaseHelper(DataCollectActivity.this);
//        SQLiteDatabase sqliteDatabase = dbHelper.getWritableDatabase();
//        sqliteDatabase.execSQL("delete from user");
    }

    @SuppressLint("NonConstantResourceId")
    public void onClick(View v){
        switch (v.getId()) {
            case R.id.btn_connect:
                startConnectDevice();
                break;
            case R.id.btn_info:
                llChartView.setVisibility(View.GONE);
                llInfoView.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_save_info:
                String name = edtUserName.getText().toString().trim();
                String age = edtUserAge.getText().toString().trim();
                String height = edtUserHeight.getText().toString().trim();
                String weight = edtUserWeight.getText().toString().trim();
                if(name.isEmpty()||age.isEmpty()||height.isEmpty()||weight.isEmpty()){
                    Toast.makeText(DataCollectActivity.this,"信息填写不完整!", Toast.LENGTH_SHORT).show();
                }else{
                    userInfo.add(name);
                    userInfo.add(checkedGender);
                    userInfo.add(age);
                    userInfo.add(height);
                    userInfo.add(weight);
                    Toast.makeText(DataCollectActivity.this,"信息保存成功!", Toast.LENGTH_SHORT).show();
                    edtUserName.setText("");
                    edtUserAge.setText("");
                    rgUserGender.check(R.id.gender_male);
                    edtUserHeight.setText("");
                    edtUserWeight.setText("");
                    llInfoView.setVisibility(View.INVISIBLE);
                }
                break;
            case R.id.btn_collect:
                if (btnCollect.getText().toString().equals("开始采集")){
                    llInfoView.setVisibility(View.GONE);
                    llChartView.setVisibility(View.VISIBLE);
                    llInference.setVisibility(View.INVISIBLE);
                    String data_send_cmd = "1\r\n";
                    mmConnectedThread.write(data_send_cmd.getBytes());
                    btnCollect.setText("停止采集");
                    btnRecord.setEnabled(false);
                    btnInfo.setEnabled(false);
                    recordData = new ArrayList<>();
                    isRecord = true;
                }else{
                    String data_send_cmd = "0\r\n";
                    mmConnectedThread.write(data_send_cmd.getBytes());
                    btnCollect.setText("开始采集");
                    btnRecord.setEnabled(true);
                    btnInfo.setEnabled(true);
                    isRecord = false;
                }
                break;
            case R.id.btn_record:
                if(userInfo==null||userInfo.isEmpty()){
                    Toast.makeText(DataCollectActivity.this,"请先填写个人信息", Toast.LENGTH_SHORT).show();
                }else{
                    if(saveData(recordData)){
                        Toast.makeText(DataCollectActivity.this,"保存成功！", Toast.LENGTH_SHORT).show();
                        llChartView.setVisibility(View.INVISIBLE);
                        // 清除用户信息
                        userInfo.clear();
                        recordData.clear();
                        drawDataQueue.clear();
                        for(int i=0; i<refreshSize; i++) drawDataQueue.add("0,0");
                        rcvCount = 0;
                    }
                    else { Toast.makeText(DataCollectActivity.this,"保存失败！", Toast.LENGTH_SHORT).show(); }
                }
                break;
            case R.id.btn_inference:
                // signal process, return the number of lines in csv
                int lines = QRSDetectorOffline.detectQRS(externalFilesDirPath, dataSaveName);
                // ensure signal process done
                if(lines!=-1){
                    String className = Classifier.modelInference(DataCollectActivity.this, externalFilesDirPath, dataSaveName, lines);
                    tvInference.setText(className);
                }
                llInference.setVisibility(View.VISIBLE);
                break;
        }
    }

    /**
     * 解决：无法发现蓝牙设备的问题
     *
     * 对于发现新设备这个功能, 还需另外两个权限(Android M 以上版本需要显式获取授权,附授权代码):
     */
    private final int ACCESS_LOCATION=1;
//    private final int STORAGE_PERMISSION=2;
    @SuppressLint("WrongConstant")
    private void getPermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            int permissionCheck;
            permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);

            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                //未获得权限
                this.requestPermissions( // 请求授权
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        ACCESS_LOCATION);// 自定义常量,任意整型
            }
//            if (this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
//                    this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//                //未获得权限
//                this.requestPermissions( // 请求授权
//                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
//                                Manifest.permission.WRITE_EXTERNAL_STORAGE},
//                        ACCESS_LOCATION);// 自定义常量,任意整型
//            }
        }
    }

    /**
     * 请求权限的结果回调。每次调用 requestpermissions（string[]，int）时都会调用此方法。
     * @param requestCode 传入的请求代码
     * @param permissions 传入permissions的要求
     * @param grantResults 相应权限的授予结果:PERMISSION_GRANTED 或 PERMISSION_DENIED
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean flag = hasAllPermissionGranted(grantResults);
        switch (requestCode) {
            case ACCESS_LOCATION:
                if (flag) {
                    Log.i(TAG, "onRequestPermissionsResult: 用户允许蓝牙权限");
                } else {
                    Log.i(TAG, "onRequestPermissionsResult: 拒绝搜索设备权限");
                }
                break;
//            case STORAGE_PERMISSION:
//                if (flag) {
//                    Log.i(TAG, "onRequestPermissionsResult: 用户允许存储权限");
//                } else {
//                    Log.i(TAG, "onRequestPermissionsResult: 用户拒绝存储权限");
//                }
//                break;
        }
    }

    private boolean hasAllPermissionGranted(int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }

    /**
     * bluetooth 查找目标设备
     * */
    private boolean findTargetDevice(String targetDevice) {
        Set<BluetoothDevice> pairedSet = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice id : pairedSet) {
            if (id.getName().equals(targetDevice)) {
                pairedDevice.setText(pairedDevice.getText() + targetDevice);
                return true;
            }
        }
        return false;
    }
    /**
     * bluetooth 初始化
     * */
    private boolean bluetoothInit () {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(DataCollectActivity.this, "当前手机设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            return false;
        }
        //手机设备支持蓝牙，判断蓝牙是否已开启
        if (bluetoothAdapter.isEnabled()) {
            Toast.makeText(DataCollectActivity.this, "手机蓝牙已开启", Toast.LENGTH_SHORT).show();
        } else {
            //蓝牙没有打开，去打开蓝牙。推荐使用第二种打开蓝牙方式
            //第一种方式：直接打开手机蓝牙，没有任何提示
            //第二种方式：友好提示用户打开蓝牙
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
        }
        if (!findTargetDevice(targetBtDevice)) Toast.makeText(DataCollectActivity.this, "请先配对！", Toast.LENGTH_LONG).show();
        return true;
    }
    /**
     * 开始连接设备
     */
    public void startConnectDevice(){
        Set<BluetoothDevice> paired_set = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice bd: paired_set) {
            // 找到目标设备，创建连接线程
            if (bd.getName().equals(targetBtDevice)) {
                mmConnectThread = new ConnectThread(bluetoothAdapter, bd);
                mmConnectThread.start();
                mmConnectThread.setOnBluetoothConnectListener(new ConnectThread.OnBluetoothConnectListener() {
                    @Override
                    public void onConnSuccess(BluetoothSocket bluetoothSocket) {
                        Log.w(TAG,"startConnectDevice-->连接成功");
                        //标记当前连接状态为true
                        curConnState = true;
                        Message msg = new Message();
                        msg.what = STATE_MSG;
                        msg.obj = "SUCCESS";
                        //发送通知
                        mHandler.sendMessage(msg);
                        //管理连接，收发数据
                        managerConnectSendReceiveData(bluetoothSocket);
                    }
                    @Override
                    public void onConnFailure(String errorMsg){
                        Log.e(TAG,"startConnectDevice-->" + errorMsg);
                        //标记当前连接状态为false
                        curConnState = false;
                        Message msg = new Message();
                        msg.what = STATE_MSG;
                        msg.obj = "FAILURE";
                        mHandler.sendMessage(msg);
                    }
                });
                break;
            }
        }
    }
    /**
     * 管理已建立的连接，收发数据
     * @param bluetoothSocket   已建立的连接
     */
    public void managerConnectSendReceiveData(BluetoothSocket bluetoothSocket){
        //管理已有连接
        mmConnectedThread = new ConnectedThread(bluetoothSocket);
        mmConnectedThread.start();
        mmConnectedThread.setOnSendReceiveDataListener(new ConnectedThread.OnSendReceiveDataListener() {
            @Override
            public void onReceiveDataSuccess(byte[] buffer) {
//                Log.w(TAG,"成功接收数据,长度" + buffer.length + "->" + bytes2String(buffer));
                Message msg = new Message();
                msg.what = DATA_MSG;
                msg.obj = bytes2String(buffer);
                mHandler.sendMessage(msg);
            }
            @Override
            public void onReceiveDataError(String errorMsg) {
                Log.e(TAG,"接收数据出错：" + errorMsg);
            }
        });
    }
    /**
     * 字节数组-->字符串
     * @param b   字节数组
     * @return 字符串
     */
    public static String bytes2String(byte[] b){
        int bcg = (((b[0] & 0xFF)<<8) | (b[1] & 0xFF));
        int ecg = (((b[2] & 0xFF)<<8) | (b[3] & 0xFF));
        String strContent = bcg + "," + ecg;
        return strContent;
    }

    public boolean saveData(List<String> data){
        // 先保存测试者信息
        ContentValues values = new ContentValues();
        values.put("name",userInfo.get(0));
        values.put("gender",userInfo.get(1));
        values.put("age",Integer.parseInt(userInfo.get(2)));
        values.put("height",Integer.parseInt(userInfo.get(3)));
        values.put("weight",Integer.parseInt(userInfo.get(4)));
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());//设置日期格式
        values.put("datetime",df.format(new Date()));// new Date()为获取当前系统时间
        // 创建数据库
        DataBaseHelper dbHelper = new DataBaseHelper(DataCollectActivity.this);
        SQLiteDatabase sqliteDatabase = dbHelper.getWritableDatabase();
        // 数据库执行插入命令
        sqliteDatabase.insert("user", null, values);
        //创建游标对象
        Cursor cur = sqliteDatabase.rawQuery("select LAST_INSERT_ROWID() ",null);
        cur.moveToFirst();
        int id = cur.getInt(0);
        // 关闭游标，释放资源
        cur.close();

        // 保存信号数据
        // 如果手机插入了SD卡，而且应用程序具有访问SD的权限
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) { //sd卡处于挂载状态
            dataSaveName = id + "_" + userInfo.get(0);
            String fileName = dataSaveName + ".txt";
            //获取要写入的文件目录  storage/sdcard/Android/data/包名/files/xxx.txt
            //创建指定目录下的文件
            File file = new File(externalFilesDirPath,fileName);
            //开始写文件
            if (!file.exists()) {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            }
            // 写入文件
            try {
                FileWriter fileWriter=new FileWriter(file);
                for (String s: data)
                    fileWriter.write(s);
                fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            return true;
        } else {
            Toast.makeText(this, "找不到指定的SD卡", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    // 图表相关函数——根据数据生成线条
    private void generateLine(Queue<String> queue) {
        List<PointValue> bcgPoints = new ArrayList<>();
        List<PointValue> ecgPoints = new ArrayList<>();

        // 分割原始数据
        int idx = 0;
        for (String str: queue) {
            String[] split_data = str.split(",");
            int data0 = Integer.parseInt(split_data[0]);
            int data1 = Integer.parseInt(split_data[1]);
            bcgPoints.add(new PointValue(idx, data0));
            ecgPoints.add(new PointValue(idx, data1));
            idx++;
        }

        // 根据创建的 点 创建 线条， 并设置线条的外观
        bcgLine = new Line(bcgPoints);
        bcgLine.setColor(Color.parseColor("#D54C4C"));
        bcgLine.setStrokeWidth(2);
        bcgLine.setCubic(true);  //设置是平滑的还是直的
        bcgLine.setPointRadius(2);
        bcgLine.setHasLabelsOnlyForSelected(true);

        ecgLine = new Line(ecgPoints);
        ecgLine.setColor(Color.parseColor("#D54C4C"));
        ecgLine.setStrokeWidth(2);
        ecgLine.setCubic(true);  //设置是平滑的还是直的
        ecgLine.setPointRadius(2);
        ecgLine.setHasLabelsOnlyForSelected(true);
    }

    // 图表相关函数 - 绘图
    private void drawChart(LineChartView chart, String chartName) {
        List<Line> lines = new ArrayList<>();
        if (chartName.equals("BCG")) lines.add(bcgLine);
        else lines.add(ecgLine);

        chart.setInteractive(true);
        chart.setZoomType(ZoomType.HORIZONTAL_AND_VERTICAL);
        LineChartData data = new LineChartData();
        Axis axisX = new Axis();//x轴
        Axis axisY = new Axis();//y轴
        axisX.setName(chartName);
        axisX.setTextSize(10);
        axisY.setTextSize(7);
        axisX.setTextColor(Color.parseColor("#323232"));
        axisY.setTextColor(Color.parseColor("#323232"));
        axisY.setInside(true);	//将轴数据显示在内侧
        axisX.setHasLines(true);//设置是否显示坐标网格。
        axisY.setHasLines(true);//设置是否显示坐标网格。
        axisX.setLineColor(Color.parseColor("#66F7B77D"));//设置网格线的颜色
        axisY.setLineColor(Color.parseColor("#66F7B77D"));//设置网格线的颜色

        data.setAxisXBottom(axisX);
        data.setAxisYLeft(axisY);

        data.setLines(lines);
        chart.setLineChartData(data);  //给图表设置数据
        chart.setBackgroundColor(Color.parseColor("#FFFAF0"));
    }

    // Animators may only be run on Looper threads
    // 所以要这么传
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case DATA_MSG: //数据消息
                    if(isRecord){
                        String sendData = (String) msg.obj;
                        String[] data = sendData.split(",");
                        tvBCG.setText("BCG:"+data[0]);
                        tvECG.setText("ECG:"+data[1]);
                        rcvCount = (rcvCount % 65535) + 1;
                        tvCNT.setText("计数：" + rcvCount);
                        recordData.add(sendData);
                        if(drawDataQueue.size()<refreshSize){
                            drawDataQueue.add(sendData);
                            break;
                        }
                        // 调用画图函数
                        // 产生线条 - 绘图
                        generateLine(drawDataQueue);
                        drawChart(bcgChart, "BCG");
                        drawChart(ecgChart, "ECG");

                        drawDataQueue.poll();
                        drawDataQueue.add(sendData);
                    }
                    break;
                case STATE_MSG: //连接状态消息
                    String sendState = (String) msg.obj;
                    if(sendState.equals("SUCCESS")){
                        deviceState.setText("连接成功");
                        llBtInfo.setVisibility(View.VISIBLE);
                        btnConnect.setEnabled(false);
                        btnCollect.setEnabled(true);
                    }else {
                        deviceState.setText("连接失败");
                        llBtInfo.setVisibility(View.VISIBLE);
                        btnConnect.setEnabled(true);
                        btnCollect.setEnabled(false);
                    }
                    break;
            }
        }
    };
}
